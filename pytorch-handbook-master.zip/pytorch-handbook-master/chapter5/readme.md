# Pytorch 中文手册第五章 ： 应用

## 目录

## 第一节 Kaggle介绍
[Kaggle介绍](5.1-kaggle.md)
## 第二节 结构化数据
## 第三节 计算机视觉
[Fashion MNIST 图像分类](5.3-Fashion-MNIST.ipynb)
## 第四节 自然语言处理
## 第五节 协同过滤