---
name: Bug report
about: bug相关issue请按照此模板填写否则会被直接关闭
title: ''
labels: ''
assignees: ''

---

**bug描述**
描述一下你遇到的bug, 例如报错位置、报错信息（重要, 可以直接截个图）等

**版本信息**
pytorch:
torchvision:
torchtext:
...
